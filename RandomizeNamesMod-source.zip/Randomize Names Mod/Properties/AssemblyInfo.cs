﻿using System.Reflection;
using MelonLoader;
using Randomize_Names_Mod;

[assembly: AssemblyVersion("1.0.0.0")]
[assembly: AssemblyTitle("Among Us VR - Confusing Names")]
[assembly: AssemblyDescription("Among Us VR - Confusing Names")]
[assembly: AssemblyCompany(null)]
[assembly: AssemblyProduct("Among Us VR - Confusing Names")]
[assembly: AssemblyCopyright("Created by YouTubey")]
[assembly: AssemblyTrademark(null)]
[assembly: AssemblyFileVersion("0.0.1")]
[assembly: MelonInfo(typeof(ModClass), "Among Us VR - Confusing Names", "1.0.0", "YouTubey", null)]
[assembly: MelonColor]
[assembly: MelonGame("Schell Games", "Among Us VR")]
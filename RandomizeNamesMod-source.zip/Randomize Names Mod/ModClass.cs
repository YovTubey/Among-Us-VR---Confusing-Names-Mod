﻿using System.Collections.Generic;
using MelonLoader;
using UnityEngine;
using SG.Airlock;
using System.IO;

namespace Randomize_Names_Mod
{
    public class ModClass : MelonMod
    {
        public bool isTitle = false;
        public bool isSkeld = false;
        private Texture2D modStampTexture;
        public GameObject questionNamesButton;
        public GameObject familyNamesButton;
        public GameObject gameFunctionsButton;
        public GameObject textObject1;
        public GameObject textObject2;
        public GameObject textObject3;

        public override void OnApplicationStart()
        {
            ////////// MOD STAMP //////////
            string path = Path.Combine(MelonHandler.ModsDirectory, "ConfusingNames_Data/Images/ModStamp.png");
            byte[] imageData = File.ReadAllBytes(path);
            modStampTexture = new Texture2D(1, 1);
            ImageConversion.LoadImage(modStampTexture, imageData);
        }
        public override void OnSceneWasLoaded(int buildIndex, string sceneName)
        {

            if (sceneName == "Skeld")
            {
                isSkeld = true;
                isTitle = false;
                new GameObject("ConfusingNames-DATA");
                Shader distanceFieldShader = Shader.Find("UI/Default");

                ////////// IMPORT HOST MOD REQUIREMENTS //////////
                // Text Background
                GameObject textBG = GameObject.CreatePrimitive(PrimitiveType.Cube);
                textBG.name = "TextBG";
                textBG.transform.position = new Vector3(43.1639f, 1.026f, -16.971f);
                textBG.transform.localScale = new Vector3(0.2f, 0.6f, 2.8f);
                textBG.transform.parent = GameObject.Find("ConfusingNames-DATA").transform;

                Renderer renderer = textBG.GetComponent<Renderer>();
                renderer.material.shader = Shader.Find("Unlit/Color");
                renderer.material.color = Color.white;

                // Question Names Button
                questionNamesButton = GameObject.CreatePrimitive(PrimitiveType.Cube);
                questionNamesButton.name = "QuestionNamesButton";
                questionNamesButton.transform.position = new Vector3(43.0539f, 0.726f, -15.871f);
                questionNamesButton.transform.localScale = new Vector3(0.2f, 0.2f, 0.2f);
                questionNamesButton.transform.parent = GameObject.Find("ConfusingNames-DATA").transform;

                Renderer questionNamesButtonRenderer = questionNamesButton.GetComponent<Renderer>();
                questionNamesButtonRenderer.material.shader = Shader.Find("Unlit/Color");
                questionNamesButtonRenderer.material.color = Color.red;


                // Question Names Text
                textObject1 = new GameObject("Text");
                textObject1.transform.parent = questionNamesButton.transform;
                TextMesh textMesh1 = textObject1.AddComponent<TextMesh>();
                textMesh1.transform.position = new Vector3(43.0539f, 1.326f, -15.471f);
                textMesh1.transform.rotation = Quaternion.Euler(0f, 90f, 0f);
                textMesh1.text = "Question\nNames";
                textMesh1.fontSize = 10;
                textObject1.transform.localScale = new Vector3(1f, 1f, 1f);
                textMesh1.fontStyle = FontStyle.Bold;
                textMesh1.alignment = TextAlignment.Center;
                textMesh1.color = Color.white;
                Material fontMaterial1 = textMesh1.font.material;
                fontMaterial1.shader = distanceFieldShader;

                // Family Names Button
                familyNamesButton = GameObject.CreatePrimitive(PrimitiveType.Cube);
                familyNamesButton.name = "FamilyNamesButton";
                familyNamesButton.transform.position = new Vector3(43.0539f, 0.726f, -16.871f);
                familyNamesButton.transform.localScale = new Vector3(0.2f, 0.2f, 0.2f);
                familyNamesButton.transform.parent = GameObject.Find("ConfusingNames-DATA").transform;

                Renderer familyNamesButtonRenderer = familyNamesButton.GetComponent<Renderer>();
                familyNamesButtonRenderer.material.shader = Shader.Find("Unlit/Color");
                familyNamesButtonRenderer.material.color = Color.red;

                // Family Names Text
                textObject2 = new GameObject("Text");
                textObject2.transform.parent = familyNamesButton.transform;
                TextMesh textMesh2 = textObject2.AddComponent<TextMesh>();
                textMesh2.transform.position = new Vector3(43.0539f, 1.326f, -16.551f);
                textMesh2.transform.rotation = Quaternion.Euler(0f, 90f, 0f);
                textMesh2.text = "Family\nNames";
                textMesh2.fontSize = 10;
                textObject2.transform.localScale = new Vector3(1f, 1f, 1f);
                textMesh2.fontStyle = FontStyle.Bold;
                textMesh2.alignment = TextAlignment.Center;
                textMesh2.color = Color.white;
                Material fontMaterial2 = textMesh2.font.material;
                fontMaterial2.shader = distanceFieldShader;

                // Game Functions Button
                gameFunctionsButton = GameObject.CreatePrimitive(PrimitiveType.Cube);
                gameFunctionsButton.name = "GameFunctionsButton";
                gameFunctionsButton.transform.position = new Vector3(43.0539f, 0.726f, -17.871f);
                gameFunctionsButton.transform.localScale = new Vector3(0.2f, 0.2f, 0.2f);
                gameFunctionsButton.transform.parent = GameObject.Find("ConfusingNames-DATA").transform;

                Renderer gameFunctionsButtonRenderer = gameFunctionsButton.GetComponent<Renderer>();
                gameFunctionsButtonRenderer.material.shader = Shader.Find("Unlit/Color");
                gameFunctionsButtonRenderer.material.color = Color.red;

                // Game Functions Text
                textObject3 = new GameObject("Text");
                textObject3.transform.parent = gameFunctionsButton.transform;
                TextMesh textMesh3 = textObject3.AddComponent<TextMesh>();
                textMesh3.transform.position = new Vector3(43.0539f, 1.326f, -17.411f);
                textMesh3.transform.rotation = Quaternion.Euler(0f, 90f, 0f);
                textMesh3.text = "Game\nFunctions";
                textMesh3.fontSize = 10;
                textObject3.transform.localScale = new Vector3(1f, 1f, 1f);
                textMesh3.fontStyle = FontStyle.Bold;
                textMesh3.alignment = TextAlignment.Center;
                textMesh3.color = Color.white;
                Material fontMaterial3 = textMesh3.font.material;
                fontMaterial3.shader = distanceFieldShader;
            }
            if (sceneName == "Title")
            {
                isSkeld = false;
                isTitle = true;
            }
        }

        public override void OnUpdate()
        {
            if (modStampTexture == null)
            {
                string imagePath = Path.Combine(MelonHandler.ModsDirectory, "ConfusingNames_Data/Images/ModStamp.png");
                byte[] imageBytes = File.ReadAllBytes(imagePath);
                modStampTexture = new Texture2D(2, 2);
                ImageConversion.LoadImage(modStampTexture, imageBytes);
            }

            if (isSkeld == true)
            {
                // Components
                GameSession gameSession = GameObject.Find("GameSession").GetComponent<GameSession>();

                // Player's Hands
                Transform LeftHand = GameObject.Find("LeftHand").transform;
                Transform RightHand = GameObject.Find("RightHand").transform;

                // Checks for private lobbies only.
                if (gameSession.IsPrivate == false)
                {
                    Application.Quit();
                }

                // Set All Players Red
                if (gameSession.IsPrivate == true)
                {
                    for (int playerNumber = 0; playerNumber < 10; playerNumber++)
                    {
                        PlayerState Player = GameObject.Find("PlayerState (" + playerNumber + ")").GetComponent<PlayerState>();
                        Player.RPC_UpdateColorID(0);
                    }
                }

                // Button Collision Checkers
                float questionsLeftHand = Vector3.Distance(LeftHand.position, questionNamesButton.transform.position);
                float questionsRightHand = Vector3.Distance(RightHand.position, questionNamesButton.transform.position);
                float familyLeftHand = Vector3.Distance(LeftHand.position, familyNamesButton.transform.position);
                float familyRightHand = Vector3.Distance(RightHand.position, familyNamesButton.transform.position);
                float functionsLeftHand = Vector3.Distance(LeftHand.position, gameFunctionsButton.transform.position);
                float functionsRightHand = Vector3.Distance(RightHand.position, gameFunctionsButton.transform.position);

                // Button Collisions
                float questionsButton = questionNamesButton.transform.localScale.x / 2;
                float familyButton = familyNamesButton.transform.localScale.x / 2;
                float functionsButton = gameFunctionsButton.transform.localScale.x / 2;

                if (gameSession.Runner.IsHostPlayer(gameSession.Runner.LocalPlayer))
                {
                    if (questionsLeftHand <= questionsButton || questionsRightHand <= questionsButton)
                    {
                        List<string> nameList = new List<string> { "Where was?", "Who did?", "What was?", "Why was?", "When was?", "How did?", "Did you?", "Does the?", "Why did?", "Which one?" };

                        for (int playerNumber = 0; playerNumber < 10; playerNumber++)
                        {
                            // Get Random Name
                            int randomIndex = UnityEngine.Random.Range(0, nameList.Count);
                            string randomName = nameList[randomIndex];

                            PlayerState Player = GameObject.Find("PlayerState (" + playerNumber + ")").GetComponent<PlayerState>();

                            Player.RPC_SetNetworkName(randomName);
                            nameList.RemoveAt(randomIndex);
                        }
                    }

                    if (familyLeftHand <= familyButton || familyRightHand <= familyButton)
                    {
                        List<string> nameList = new List<string> { "Mommy", "Daddy", "Brother", "Sister", "My Baby", "Gandma", "Grampa", "Step-Bro", "Uncle", "Auntie" };

                        for (int playerNumber = 0; playerNumber < 10; playerNumber++)
                        {
                            // Get Random Name
                            int randomIndex = UnityEngine.Random.Range(0, nameList.Count);
                            string randomName = nameList[randomIndex];

                            PlayerState Player = GameObject.Find("PlayerState (" + playerNumber + ")").GetComponent<PlayerState>();

                            Player.RPC_SetNetworkName(randomName);
                            nameList.RemoveAt(randomIndex);
                        }
                    }

                    if (functionsLeftHand <= functionsButton || functionsRightHand <= functionsButton)
                    {
                        List<string> nameList = new List<string> { "Vote Me", "Vote Skip", "The Body", "Eletrical", "The Lights", "Vented", "Reported", "Imposter", "Crewmate", "Killed" };

                        for (int playerNumber = 0; playerNumber < 10; playerNumber++)
                        {
                            // Get Random Name
                            int randomIndex = UnityEngine.Random.Range(0, nameList.Count);
                            string randomName = nameList[randomIndex];

                            PlayerState Player = GameObject.Find("PlayerState (" + playerNumber + ")").GetComponent<PlayerState>();

                            Player.RPC_SetNetworkName(randomName);
                            nameList.RemoveAt(randomIndex);
                        }
                    }
                }
            }
        }

        ////////// MOD STAMP //////////
        public override void OnGUI()
        {
            GUI.DrawTexture(new Rect(Screen.width - 128f, 0f, 128f, 128f), modStampTexture);
        }
    }
}

How to use the mod:

Step 1:
- Make sure MelonLoader has been installed for Among Us VR.

Step 2:
- Put the two otehr files (ConfusingNames.dll and ConfusingNames_Data) into the Mods folder.

Step 3:
- Enjoy! :)